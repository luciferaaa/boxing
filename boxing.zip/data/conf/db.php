<?php
/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'boxing',
    'DB_USER' => 'root',
    'DB_PWD' => 'root',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'boxing_',
    //密钥
    "AUTHCODE" => 'EEEoWABVYRZrqogOuu',
    //cookies
    "COOKIE_PREFIX" => 'cc84Uw_',
);
