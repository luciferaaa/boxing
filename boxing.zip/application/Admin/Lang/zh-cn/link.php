<?php
return array(
    "NAME" => "链接名称",
    "LINK_ADDRESS" => '链接地址',
    "LINK_ICON" => '链接图标',
    "LINK_TARGET" => '打开方式',
    "LINK_DESCRIPTION" => '描述'
);