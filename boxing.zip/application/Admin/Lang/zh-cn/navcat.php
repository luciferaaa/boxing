<?php
return array(
		"NAME" => '名称',
		"DESCRIPTION" => '描述',
		"MAIN_NAVCAT" => '主菜单',
		"CATEGORY_NAME" => '分类名称',
);