<?php
return array (
  'API_GUESTBOOKADMIN_DELETE' => '删除网站留言',
  'API_GUESTBOOKADMIN_INDEX' => 'Guestbook',
  'API_OAUTHADMIN_SETTING_POST' => '提交设置',
  'API_OAUTHADMIN_SETTING' => 'Third Party Landing',
);